// ============================================================
// TOP SECRET LOGIN SYSTEM — WITH SOUND FX & ENCRYPTION
// Website content is XOR encrypted — only decrypted on valid login
// ============================================================

const VALID_USER = 'admin';
const VALID_PASS = 'abcd123456';

const loginScreen = document.getElementById('loginScreen');
const websiteContent = document.getElementById('websiteContent');
const loginForm = document.getElementById('loginForm');
const loginUser = document.getElementById('loginUser');
const loginPass = document.getElementById('loginPass');
const loginError = document.getElementById('loginError');
const loginBtn = document.getElementById('loginBtn');
const loginStatus = document.getElementById('loginStatus');
const loginTimeEl = document.getElementById('loginTime');

// ============================================================
// WEB AUDIO — MATRIX SOUND EFFECTS ENGINE
// ============================================================
let audioCtx = null;

function initAudio() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') audioCtx.resume();
}

// Matrix ambient drone
function playAmbientDrone() {
    initAudio();
    const osc1 = audioCtx.createOscillator();
    const osc2 = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();

    osc1.type = 'sine';
    osc1.frequency.value = 55;
    osc2.type = 'sine';
    osc2.frequency.value = 57;

    filter.type = 'lowpass';
    filter.frequency.value = 200;

    gain.gain.value = 0;
    gain.gain.linearRampToValueAtTime(0.04, audioCtx.currentTime + 2);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(audioCtx.destination);

    osc1.start();
    osc2.start();

    return { osc1, osc2, gain };
}

// Keypress click sound
function playKeyClick() {
    initAudio();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'square';
    osc.frequency.value = 800 + Math.random() * 400;

    gain.gain.value = 0.08;
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.05);
}

// Scan/processing sound
function playScanSound() {
    initAudio();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.value = 100;
    osc.frequency.linearRampToValueAtTime(2000, audioCtx.currentTime + 1.2);

    filter.type = 'bandpass';
    filter.frequency.value = 800;
    filter.Q.value = 5;

    gain.gain.value = 0.06;
    gain.gain.linearRampToValueAtTime(0.001, audioCtx.currentTime + 1.5);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 1.5);
}

// Access denied alarm
function playDeniedSound() {
    initAudio();
    for (let i = 0; i < 3; i++) {
        setTimeout(() => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();

            osc.type = 'square';
            osc.frequency.value = 220;

            gain.gain.value = 0.12;
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);

            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.15);
        }, i * 180);
    }
}

// Access granted triumphant sound
function playGrantedSound() {
    initAudio();
    const notes = [523, 659, 784, 1047]; // C5, E5, G5, C6
    notes.forEach((freq, i) => {
        setTimeout(() => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();

            osc.type = 'sine';
            osc.frequency.value = freq;

            gain.gain.value = 0.15;
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);

            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.4);
        }, i * 150);
    });
}

// Matrix digital rain sound
function playMatrixRain() {
    initAudio();
    for (let i = 0; i < 8; i++) {
        setTimeout(() => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();

            osc.type = 'sine';
            osc.frequency.value = 2000 + Math.random() * 4000;

            gain.gain.value = 0.02;
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);

            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.1);
        }, i * 60);
    }
}

// Hover sound
function playHoverSound() {
    initAudio();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'sine';
    osc.frequency.value = 1200;

    gain.gain.value = 0.03;
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.08);
}

// Boot-up sequence sound
function playBootSequence() {
    initAudio();
    const freqs = [200, 300, 400, 500, 600, 800, 1000, 1200];
    freqs.forEach((freq, i) => {
        setTimeout(() => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = 'sine';
            osc.frequency.value = freq;
            gain.gain.value = 0.04;
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.08);
        }, i * 80);
    });
}

// ============================================================
// DECRYPTION ENGINE
// ============================================================
function xorDecrypt(base64Data, key) {
    // Decode base64 to binary string
    const binaryStr = atob(base64Data);
    let result = '';
    for (let i = 0; i < binaryStr.length; i++) {
        result += String.fromCharCode(
            binaryStr.charCodeAt(i) ^ key.charCodeAt(i % key.length)
        );
    }
    return result;
}

// ============================================================
// LOGIN LOGIC
// ============================================================
let ambientDrone = null;

// Update time
function updateTime() {
    const now = new Date();
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getMinutes()).padStart(2, '0');
    const s = String(now.getSeconds()).padStart(2, '0');
    loginTimeEl.textContent = `${h}:${m}:${s} UTC`;
}
setInterval(updateTime, 1000);
updateTime();

// Generate floating particles
function createParticles() {
    const container = document.getElementById('particles');
    for (let i = 0; i < 30; i++) {
        const particle = document.createElement('span');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = (60 + Math.random() * 40) + '%';
        particle.style.animationDelay = Math.random() * 8 + 's';
        particle.style.animationDuration = (6 + Math.random() * 6) + 's';
        container.appendChild(particle);
    }
}
createParticles();

// Start ambient on first interaction
document.addEventListener('click', function startAmbient() {
    if (!ambientDrone) {
        ambientDrone = playAmbientDrone();
        playBootSequence();
    }
    document.removeEventListener('click', startAmbient);
}, { once: false });

document.addEventListener('keydown', function startAmbientKey() {
    if (!ambientDrone) {
        ambientDrone = playAmbientDrone();
    }
    document.removeEventListener('keydown', startAmbientKey);
}, { once: false });

// Key press sounds
loginUser.addEventListener('input', () => {
    playKeyClick();
    loginError.classList.remove('show');
});
loginPass.addEventListener('input', () => {
    playKeyClick();
    loginError.classList.remove('show');
});

// Focus sounds
loginUser.addEventListener('focus', () => {
    playHoverSound();
    loginStatus.textContent = 'STATUS: ENTERING AGENT ID';
});
loginPass.addEventListener('focus', () => {
    playHoverSound();
    loginStatus.textContent = 'STATUS: ENTERING ACCESS CODE';
});

// Button hover
loginBtn.addEventListener('mouseenter', () => {
    playHoverSound();
});

// Handle form submit
loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    initAudio();

    const username = loginUser.value.trim();
    const password = loginPass.value.trim();

    loginError.classList.remove('show');
    loginBtn.classList.add('loading');
    loginStatus.textContent = 'STATUS: AUTHENTICATING...';

    // Play scanning sound
    playScanSound();
    playMatrixRain();

    // Simulate authentication delay
    setTimeout(() => {
        if (username === VALID_USER && password === VALID_PASS) {
            // SUCCESS — Decrypt and reveal
            loginStatus.textContent = 'STATUS: ACCESS GRANTED';
            loginBtn.classList.remove('loading');
            loginScreen.classList.add('success');
            playGrantedSound();

            // Decrypt the website content
            try {
                const decrypted = xorDecrypt(ENCRYPTED_PAYLOAD, password);
                websiteContent.innerHTML = decrypted;
            } catch (err) {
                console.error('Decryption failed');
            }

            // Stop ambient drone
            if (ambientDrone) {
                ambientDrone.gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 1);
                setTimeout(() => {
                    ambientDrone.osc1.stop();
                    ambientDrone.osc2.stop();
                }, 1200);
            }

            // Show ACCESS GRANTED overlay
            setTimeout(() => {
                showAccessGranted();
            }, 600);
        } else {
            // FAILURE
            loginBtn.classList.remove('loading');
            loginError.classList.add('show');
            loginStatus.textContent = 'STATUS: ACCESS DENIED';
            playDeniedSound();

            loginUser.style.borderColor = 'rgba(255, 51, 68, 0.5)';
            loginPass.style.borderColor = 'rgba(255, 51, 68, 0.5)';
            setTimeout(() => {
                loginUser.style.borderColor = '';
                loginPass.style.borderColor = '';
                loginStatus.textContent = 'STATUS: AWAITING INPUT';
            }, 2500);
        }
    }, 1800);
});

function showAccessGranted() {
    const overlay = document.createElement('div');
    overlay.className = 'access-granted show';
    overlay.innerHTML = `
        <span class="access-granted__text">ACCESS GRANTED</span>
        <span class="access-granted__sub">WELCOME, AGENT</span>
        <span class="access-granted__decrypting">DECRYPTING SECURE CONTENT...</span>
    `;
    document.body.appendChild(overlay);

    setTimeout(() => {
        loginScreen.style.display = 'none';
        overlay.style.display = 'none';
        websiteContent.style.display = 'block';
        document.title = 'Your Company \u2014 Property & Lifestyle Management';

        websiteContent.style.opacity = '0';
        websiteContent.style.transition = 'opacity 0.8s ease';
        requestAnimationFrame(() => {
            websiteContent.style.opacity = '1';
        });
    }, 2500);
}

// Disable right-click and view-source shortcuts on the page
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', function(e) {
    // Disable F12, Ctrl+U, Ctrl+Shift+I, Ctrl+Shift+J
    if (e.key === 'F12' ||
        (e.ctrlKey && e.key === 'u') ||
        (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'J' || e.key === 'j'))) {
        e.preventDefault();
    }
});
